import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Destino1Page } from './destino1';

@NgModule({
  declarations: [
    Destino1Page,
  ],
  imports: [
    IonicPageModule.forChild(Destino1Page),
  ],
})
export class Destino1PageModule {}
